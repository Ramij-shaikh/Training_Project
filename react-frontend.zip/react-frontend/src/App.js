import React from 'react';
import './App.css';
import UserComponent from './components/UserComponent';

function App() {
  return (
        <UserComponent />
    
  );
}

export default App;
